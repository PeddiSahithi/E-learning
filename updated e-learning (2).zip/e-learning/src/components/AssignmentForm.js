import { useState } from 'react';
import './AssignmentForm.css';

export default function AssignmentForm() {
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [subject, setSubject] = useState(''); // State to store selected subject
  const [title, setTitle] = useState(''); // State for assignment title

  const handleSubmit = (e) => {
    e.preventDefault();

    // Check if a subject is selected
    if (!subject) {
      setError('Please select a subject');
      return;
    }

    // Check if a title is entered
    if (!title) {
      setError('Please enter an assignment title');
      return;
    }

    // Check if a file is selected
    if (!file) {
      setError('Please upload a PDF file');
      return;
    }

    // Check if the uploaded file is a PDF
    if (file.type !== 'application/pdf') {
      setError('Only PDF files are allowed');
      return;
    }

    // Simulating form submission
    console.log('Assignment Submitted:', { subject, title, file });
    alert('Assignment submitted successfully!');

    // Reset form fields and error message
    setFile(null);
    setError('');
    setSubject('');
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit} className="assignment-form">
      <h2>Submit Your Assignment</h2>

      <div className="form-group">
        <label htmlFor="subject">Subject:</label>
        <select
          id="subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          required
        >
          <option value="">Select a subject</option>
          <option value="Mathematics">Mathematics</option>
          <option value="Science">Science</option>
          <option value="History">History</option>
          <option value="English">English</option>
          <option value="Computer Science">Computer Science</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="title">Assignment Title:</label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter assignment title"
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="file">Upload PDF:</label>
        <input 
          type="file" 
          id="file"
          accept="application/pdf" 
          onChange={(e) => {
            setFile(e.target.files[0]);
            setError('');
          }} 
          required
        />
      </div>

      {error && <p className="error">{error}</p>}

      <button type="submit" className="submit-button">Submit Assignment</button>
    </form>
  );
}
