import { useState } from 'react'; 
import './ReviewForm.css'; // Import CSS for styling

export default function ReviewForm({ assignmentId }) {
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(5);
  const [name, setName] = useState(''); // State for name
  const [teacherName, setTeacherName] = useState(''); // State for teacher's name
  const [subject, setSubject] = useState(''); // State for subject
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate inputs
    if (!feedback || !name || !teacherName || !subject) {
      alert('Please fill in all fields.');
      return;
    }

    if (rating < 1 || rating > 10) {
      alert('Rating must be between 1 and 10.');
      return;
    }

    console.log('Review Submitted:', { name, teacherName, subject, feedback, rating });
    setMessage('Review submitted successfully!');

    // Clear the form
    setName('');
    setTeacherName('');
    setSubject('');
    setFeedback('');
    setRating(5);
  };

  return (
    <form onSubmit={handleSubmit} className="review-form">
      <div className="form-group">
        <label htmlFor="name">Your Name:</label>
        <input
          type="text"
          id="name"
          placeholder="Your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="teacherName">Teacher's Name:</label>
        <input
          type="text"
          id="teacherName"
          placeholder="Teacher's name"
          value={teacherName}
          onChange={(e) => setTeacherName(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="subject">Subject:</label>
        <input
          type="text"
          id="subject"
          placeholder="Subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="feedback">Feedback:</label>
        <textarea
          id="feedback"
          placeholder="Your feedback"
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="rating">Rating (1-10):</label>
        <input
          type="number"
          id="rating"
          value={rating}
          onChange={(e) => setRating(Number(e.target.value))}
          min="1"
          max="10"
          required
        />
      </div>

      <button type="submit" className="submit-button">Submit Review</button>
      
      {message && <p className="success-message">{message}</p>}
    </form>
  );
}
