import React from 'react';

export default function TeacherAssignments() {
  return (
    <div>
      <h1>Teacher Assignments</h1>
      <p>Here you can correct assignments submitted by students.</p>
    </div>
  );
}
